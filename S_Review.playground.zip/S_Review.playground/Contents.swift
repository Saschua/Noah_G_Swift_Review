/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name = "Kevin Hart"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
print; (name)
var Name = "Noah"
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let language = "Swift"
print; language
let a: Int = 21
let b: Int = 55
let c: Int = 98
let d: Double = 92.4
let e: Double = 32.1
let f: Double = 82.8
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/
let addition = a + c + b + a
let subtraction = f - e
let division = b / a
let multiplication = d * f * e
/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print (addition)
print (subtraction)
print (division)
print (multiplication)
/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant

Check the raining constant and tell the user if they need an umbrella or not

Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
if temperature >= 80{
    print ("Wear shorts")
}else{
    print("Wear jeans")
}
if raining == true{
    print ("You need an umbrella")
}else{
    print("You do not need an umbrella")
}
if time == "Morning"{
    print ("Go to school")
}
if time == "Afternoon"{
    print("Go home")
}
if time == "Night"{
    print ("Go to bed")
}
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
    let second = 10
for second in 0...second{
    print; second
}
let minutes = 10
for minutes in (0...minutes).reversed(){
    print; minutes
}
/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var array: [String] = [" "]
array.append("Red")
array.append("Yellow")
array.append("Blue")
array.append("Green")
array.append("Purple")
for array in array{
    print(array)
}
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
func multiplydouble(d: Double, f: Double) -> Double{
    return d * f
}
var answer = d * f
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
let subtract = {
    (num1: Int, num2: Int) -> Int in
    return num1 - num2
}
let result = subtract(100,49)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum groupmembers: CaseIterable{
    case Jorge
    case Muhammad
    case Charmarie
    case Vivian
    case Beatriz
    case Alonso
}
for groupmembers in groupmembers.allCases{
    print(groupmembers)
}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
struct names {
    var firstname = ""
    var middlename = ""
    var lastname = ""
    
    func fullname() -> String {
        return "This is my full name" + "\n" + firstname + " " + middlename + " " + lastname
    }
    
}
    
var wholename = names (firstname: "Noah", middlename: "Charles", lastname: "Gilliams")

wholename.fullname()

print(wholename.fullname())
 
//I accidentally deleted the instruction for the classes exercise

class coffee{
    var size: String = " "
    var caffinated: String = " "
    var cream: String = " "
    var sugar: String = " "
    
    func custom(size: String, caffinated: String, cream: String, sugar: String) -> String{
        return size + caffinated + cream + sugar
    }
}
var design = coffee()
var finishedcoffee = design.custom(size: "Large", caffinated: "No", cream: "Yes", sugar: "Yes")
